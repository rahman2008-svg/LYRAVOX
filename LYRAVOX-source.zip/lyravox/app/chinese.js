/* Traditional Chinese (Taiwan) labels are applied after all expression packs register, before the editor starts.
   Internal IDs and project JSON remain language independent. Entries without a label here keep their Japanese name. */
(() => {
  'use strict';
  const titles = {
    layout: {
      center: '置中', mixed: '大小混排', vcols: '直書', marquee: '流動橫幅', tile: '滿版鋪排',
      scatter: '散落', ring: '環形', wave: '波浪軌跡', huge: '超出畫面', labels: '標籤貼',
      condensed: '瘦長壓縮', gloss: '註解', type: '打字', diag: '斜帶', circle: '圓窗',
      stack: '殘影堆疊', pill: '膠囊', lowerThird: '下方字卡', corners: '對角配置', staircase: '階梯',
      zigzag: '鋸齒', arcTop: '彩虹弧', spiral: '螺旋', gridCells: '方格', dropCap: '首字放大',
      justified: '版心', frameBox: '畫框', bubble: '對話框', subtitleBar: '字幕條', ticker: '新聞跑馬燈',
      splitScreen: '二分割', mirror: '鏡像', sideways: '橫躺直書', edgeFrame: '沿邊環繞', perspective: '景深',
      hanko: '落款', genkou: '稿紙', panels: '漫畫分格', filmstrip: '底片', quote: '引用',
      ruler: '尺寸線', searchBar: '搜尋框', chat: '聊天', notification: '通知', ticket: '票券',
      rain: '文字雨', hanging: '吊掛', orbit: '環繞', tunnel: '隧道', wordCloud: '文字雲',
      bounceLine: '彈跳', elastic: '橡皮筋', crossBands: '交叉帶', stickerBomb: '貼紙', neon: '霓虹',
      keycaps: '鍵帽', bubbles: '泡泡', slotMachine: '拉霸機', flipBoard: '翻牌看板', credits: '片尾名單',
      zoomRepeat: '連續放大', splitHalves: '上下分割', columnsBig: '大小直排', circleWords: '同心圓', dotMatrix: '點陣顯示',
      depthStack: '景深重疊', typeSpecimen: '字型樣本', kanjiFocus: '單字強調', halfVertical: '直橫混排', curtain: '布幕',
      equalizer: '等化器', tape: '膠帶', magazine: '雜誌跨頁', headlineDeck: '標題與導言', contents: '目錄',
      footnote: '註腳', proofread: '校樣', numbered: '編號', poster: '海報', swissGrid: '瑞士網格',
      dictionary: '辭典', ema: '繪馬', ransom: '剪報字', newspaper: '報紙', vinyl: '黑膠唱片',
      cassette: '卡帶', bookSpine: '書背', polaroid: '拍立得', stampSheet: '郵票版張', postcard: '明信片',
      letterPaper: '信紙', calendar: '月曆', chochin: '燈籠', routeMap: '路線圖', stationSign: '站名牌',
      noren: '暖簾', tanzaku: '短籤', omikuji: '御神籤', kakejiku: '掛軸', shoji: '障子',
      clapper: '場記板', warningLabel: '警告標籤', priceTag: '價格標籤', nameTag: '名牌', stickyNotes: '便利貼',
      karuta: '歌牌', cube: '立方體', cylinder: '圓柱', flipCards: '翻卡', accordion: '風琴摺',
      flag: '飄揚的旗', ribbon: '緞帶', pendulum: '鐘擺', pile: '文字堆', blocks: '積木',
      balloons: '文字氣球', magnets: '磁鐵', tiles: '文字磁磚', bulbs: '燈泡招牌', ledScroll: '電子跑馬燈',
      billboard: '看板', crowdBubbles: '對話框群', crossword: '填字遊戲', wordSearch: '找字遊戲', puzzle: '拼圖',
      shadowPlay: '皮影戲', kaleido: '萬花筒', dominoes: '骨牌', burst: '爆炸', fisheye: '魚眼鏡頭',
      wall: '牆面透視', origami: '摺紙', zipper: '拉鍊', sliceStack: '切片堆疊', glitchGrid: '故障網格',
      mosaicTiles: '磁磚拼畫', maskReveal: '文字窗', contour: '等高線', halftoneBig: '網點巨字', stencil: '鏤空模板',
      title: '標題', interlude: '間奏'
    },
    enter: {
      cut: '直切', assemble: '分解→聚合', slice: '切片', type: '打字', pop: '彈出',
      drop: '落下', stretch: '伸縮', wipe: '擦除', blur: '模糊', spin: '旋轉',
      flicker: '閃爍', scramble: '亂碼', zoom: '縮放', riseMask: '由下浮現', dropMask: '由上浮現',
      slideL: '從左滑入', slideR: '從右滑入', slideWhole: '整體滑入', flipX: '縱軸翻轉', flipY: '橫軸翻轉',
      domino: '骨牌', fold: '摺疊展開', unroll: '捲軸展開', strokeDraw: '線稿到上色', outlineFill: '輪廓→填色',
      splitJoin: '上下合體', vSlice: '縱向切片', shutter: '快門', iris: '光圈', diagWipe: '斜向擦除',
      blinds: '百葉窗', checker: '棋盤格', randomOrder: '隨機順序', bounceBig: '大跳躍', squashDrop: '壓扁著地',
      rubber: '橡皮拉伸', glitchIn: '故障浮現', echoIn: '殘影聚合', whip: '急甩', skewIn: '傾斜',
      trackIn: '字距收攏', trackOut: '字距擴張', blurStagger: '模糊錯落', fadeStagger: '逐字淡入', waveIn: '波浪起伏',
      spiralIn: '螺旋聚合', zoomOut: '巨大→原尺寸', resolve: '解碼', magnet: '磁吸', inkBleed: '暈染',
      neonOn: '霓虹點亮', cursorSweep: '游標掃過', stamp: '蓋章', springIn: '彈簧', pendulum: '鐘擺',
      rollIn: '滾入', slingshot: '彈弓', rockSettle: '搖晃著地', bounceBall: '彈跳球', snapRail: '吸附對齊',
      fanOpen: '扇子展開', cylinder: '圓柱旋轉', shuffle: '洗牌', stopMotion: '定格動畫', ripple: '漣漪',
      zipper: '拉鍊', zoomAlt: '交錯縮放', tiltUp: '站起', stickerPeel: '貼上貼紙', crumple: '揉皺還原',
      noteUnfold: '展開信紙', tornJoin: '撕紙拼合', splitFlap: '翻牌', overexpose: '過曝', glint: '反光一閃',
      loupe: '放大鏡', filmFeed: '底片捲動', backlight: '逆光', lightLeak: '漏光', heatHaze: '熱浪扭曲',
      crtOn: 'CRT 開機', interlace: '交錯掃描', loadingBar: '載入條', dither: '遞色', odometer: '數字滾輪',
      matrixRain: '資料雨', hatchFill: '斜線→實心', brushReveal: '筆觸掃出', inkDrop: '墨滴', quarters: '四方聚合',
      invertBox: '反轉挖空', printRegister: '套印錯位', echoCount: '數拍進場', liquidFill: '水位上升', windBlown: '乘風而來',
      strokeOrder: '逐筆書寫', clockWipe: '順時針', shadowFirst: '影子先落', bubbles: '泡泡', tokoroten: '擠壓成條'
    },
    hold: {
      still: '靜止', jitter: '抖動', drift: '漂移', breathe: '呼吸', wave: '波浪',
      glitchtick: '故障', float: '輕飄飄', sway: '搖曳', pulse: '脈動', shimmer: '閃耀',
      colorRun: '流動色彩', rotateSlow: '緩慢旋轉', trackBreathe: '字距呼吸', skewWobble: '斜向搖晃', beatHop: '隨拍跳動',
      hWave: '橫向波浪', heartbeat: '心跳', orbitSmall: '小圓周運動', jelly: '果凍', scanBand: '掃描帶',
      noiseDrift: '雜訊漂移', tilt: '翹翹板', zoomSlow: '緩慢推近', stretchPulse: '隨拍橫向拉伸', glitchJump: '偶爾錯位',
      echoTrail: '殘影拖尾', glowFlicker: '燭火搖曳', windGust: '陣風', dangle: '懸吊', eqBounce: '隨音量伸縮',
      flashBox: '隨拍反轉', glintSweep: '光澤掃過', flipSwap: '偶爾翻面', shadowSway: '影子搖晃', magnetJiggle: '磁力',
      typeRattle: '打字震動', focusRack: '移焦', pluckString: '撥弦'
    },
    exit: {
      cut: '直切', explode: '爆散', fall: '崩落', drift: '霧散', slice: '切片退場',
      wipe: '擦除退場', shrink: '收縮', blur: '模糊退場', stretch: '伸縮退場', scatter: '飛散',
      glitch: '故障退場', sinkMask: '下沉', riseOut: '向上消失', slideOutL: '向左滑出', slideOutR: '向右滑出',
      flipOutX: '關門', flipOutY: '啪地倒下', foldOut: '摺疊收起', squash: '壓扁', trackOutWide: '字距散開',
      collapse: '吸入', zoomThrough: '衝向鏡頭', zoomFar: '退向遠方', spinOut: '旋轉消失', twist: '扭轉',
      waveOut: '波浪崩解', blurOutStagger: '逐字模糊', undraw: '回到線稿', outlineOut: '填色褪去', irisClose: '光圈',
      diagWipeOut: '斜向擦除', blindsClose: '百葉窗', checkerOut: '棋盤格', splitApart: '上下裂開', vSliceDrop: '縱向切片掉落',
      melt: '融化', dissolve: '碎散', backspace: '退格刪除', scrambleOut: '變成符號', glitchDissolve: '化為方塊',
      echoOut: '殘響', whipOut: '急甩', gravity: '重力墜落', popOut: '迸裂', burn: '燒毀',
      sweepCover: '橫條遮蓋', shatterLite: '四分飛散', peelOff: '撕下貼紙', crumpleOut: '揉成紙團丟掉', tearOut: '撕掉',
      scorchOut: '燒焦消失', overexposeOut: '過曝泛白', scanOut: '掃描線消除', stripesOut: '條紋消除', halftoneOut: '化為網點',
      eraserOut: '黑板擦擦掉', vacuumOut: '吸入一點', sandOut: '化沙飛散', shredOut: '碎紙機', dominoOut: '骨牌倒下',
      hingeOut: '單邊脫落', rocketOff: '發射升空', bounceOff: '彈跳離開', balloonOff: '氣球飛走', deflateOut: '洩氣飛走',
      hazeOut: '消失於熱浪', glassBreak: '玻璃碎裂', zipOut: '拉鍊', clapShut: '中央閉合', lampOff: '熄燈',
      slotOut: '拉霸轉動', clockOut: '時鐘擦除', matrixOut: '數位雨', tornadoOut: '龍捲風', rollUpOut: '捲起',
      snakeOut: '排隊離開', flutterOut: '飄落', rollOff: '滾走', fanClose: '收起扇子', rgbSplitOut: '分色',
      shockOut: '衝擊波', floodOut: '淹沒', slashOut: '一刀兩斷', mosaicOut: '馬賽克', scribbleOut: '亂塗抹消',
      candleOut: '吹熄'
    },
    decor: {
      brackets: '框角標記', rings: '座標圓', dots: '點狀圓環', arrows: '箭頭', slash: '斜線',
      sparks: '火花', leaders: '引線', waveform: '波形', barcode: '條碼', grid: '網格',
      stripes: '條紋', blobs: '墨漬', bars: '粗糙色帶', shapes: '幾何圖形', counter: '大數字',
      crosshair: '十字準線', cropMarks: '裁切標記', reticle: '鎖定框', radar: '雷達', progressRing: '進度環',
      timecodeBar: '時間碼', rulerEdge: '邊緣尺規', dimension: '尺寸線', indexNum: '流水號', dateStamp: '相片日期',
      qrBlock: 'QR 風格方塊', glitchRects: '故障碎片', concentricSquares: '同心方框', triangleSpin: '旋轉三角', lineBurst: '放射線',
      plusGrid: '十字網格', guides: '參考線', waveLine: '波浪線', spiralLine: '漩渦', halftonePatch: '網點',
      checkerStrip: '棋盤格帶', beatRing: '節拍圓環', orbitDots: '環繞圓點', constellation: '星座', confetti: '彩紙',
      petals: '花瓣', rainStreaks: '雨絲', snow: '雪', lightLeak: '漏光', bokeh: '散景光點',
      speedCorner: '集中線', risingParticles: '上升粒子', twinkle: '閃爍星光', brushStroke: '筆刷痕', tapePieces: '紙膠帶',
      scribbleCircle: '手繪圈', scribbleUnder: '手繪底線', crossOut: '推敲筆記', highlightMark: '螢光筆', heartsStars: '愛心與星星',
      watermarkKanji: '浮水印大字', verticalStrip: '直書條', romajiLine: '羅馬字', bracketsJP: '方頭括號', seal: '落款',
      kamon: '家紋', seigaiha: '青海波', asanoha: '麻葉紋', hanabi: '煙火', chochin: '燈籠',
      shimenawa: '注連繩', sensu: '扇子', tsukiKumo: '雲中月', momiji: '楓葉', namiGashira: '浪頭',
      kasumi: '霞', hexGrid: '六角網格', spectrumRing: '環形頻譜', dataColumns: '資料列', spinner: '載入中',
      headingTape: '方位刻度', glyphLock: '文字鎖定', atomOrbit: '原子軌道', sonarArcs: '聲波', circuit: '電路',
      swatches: '色票', ruledLines: '橫線筆記', registration: '套準標記', punchHoles: '打孔', staple: '釘書針',
      paperClip: '迴紋針', indexTabs: '索引標籤', vines: '藤蔓', cloudPuffs: '雲朵', starField: '星空',
      moonPhases: '月相', sunRays: '陽光', rainRipples: '雨滴漣漪', bubbles: '肥皂泡', smoke: '煙',
      dandelion: '蒲公英', fireflies: '螢火蟲', memphis: '孟菲斯', zigzagRibbon: '鋸齒緞帶', polkaPatch: '圓點',
      stripeCircle: '條紋圓', decoCorners: '裝飾角', halfCircles: '半圓堆疊', loopArrows: '循環箭頭', starburst: '星芒',
      tally: '畫正字', cursorClick: '游標', windowChrome: '視窗', progressBar: '進度條', toggleSwitch: '切換開關',
      notifBell: '通知', likeCounter: '按讚數', mediaControls: '播放按鈕', volumeBars: '音量', musicNotes: '音符'
    },
    treat: {
      none: '無', outline: '空心字', outlineFill: '描邊', doubleOutline: '雙層描邊', extrude: '立體字',
      longShadow: '長陰影', hardShadow: '錯位陰影', softShadow: '柔和陰影', glow: '發光', marker: '螢光筆',
      underline: '底線', strike: '刪除線', boxed: '方框字', gradientV: '垂直漸層', splitColor: '上下雙色',
      halftone: '網點', stripes: '條紋', hatch: '斜線', dotted: '點線輪廓', alternate: '交錯配色',
      italic: '斜體', wide: '扁平字', tall: '瘦長字', echoOutline: '輪廓殘響', emphasisDots: '著重號',
      neonOutline: '霓虹燈管', chrome: '鍍鉻', rainbow: '彩虹色', glitchSplit: '色版錯位', shadowStack: '多重陰影',
      stencilGap: '鏤空字', waterline: '水位', karaoke: '卡拉 OK', sizeWave: '大小節奏', rotateAlt: '搖擺字',
      baselineShift: '高低錯落', fauxBold: '超粗', circled: '圓圈字', bracketsQuote: '引號', reflection: '倒影',
      inline: '內框線', sticker: '貼紙描邊', gradientSweep: '光澤掃過', kerningWide: '寬字距', monoGrid: '稿紙風',
      outlineOffset: '錯位空心字', toneShadow: '網點陰影', fadeChars: '餘韻', cutShift: '切割錯位', focusPull: '模糊移焦',
      spotChar: '單字標記', ransom: '剪貼字'
    },
    bg: {
      none: '素色', auroraRibbons: '極光', meshBlobs: '網格漸層', duotoneSweep: '雙色掃動', horizonGlow: '行星邊緣',
      seigaiha: '青海波', asanoha: '麻葉紋', houndstooth: '千鳥格', herringbone: '人字紋', argyle: '菱格紋',
      tartan: '蘇格蘭格紋', chevron: 'V 形紋', isoCubes: '立方體', hexGrid: '六角網格', triTess: '三角馬賽克',
      moire: '摩爾紋', squareTunnel: '方形隧道', spiralArms: '漩渦', topoLines: '等高線', ridgePlot: '山脊線圖',
      starfield: '星空', nightMoon: '月夜', skyline: '街景', sunsetSun: '夕陽', oceanWaves: '海浪',
      rainWindow: '雨窗', snowLayers: '雪', fireworks: '煙火', cloudLayers: '雲', mountains: '山巒',
      filmStrip: '底片', vhsBand: 'VHS 雜訊', tornPaper: '撕紙', godRays: '光芒', vignettePulse: '彩色暗角',
      kaleidoscope: '萬花筒', marble: '大理石', paperCut: '剪紙', sunburst: '放射', concentric: '同心圓',
      halftoneFade: '網點漸層', bigStripes: '大斜紋', splitV: '左右雙色', splitH: '上下雙色', splitDiag: '斜向雙色',
      gradientSweep: '漸層', spotlight: '聚光燈', tvBars: '電視彩條', checker: '棋盤格', bigChar: '巨大文字',
      speedLines: '集中線', scanBars: '掃描線帶', dotGrid: '點狀網格', retroGrid: '復古網格', bokehBg: '散景光點',
      particlesBg: '飛舞粒子', ripples: '漣漪', polka: '圓點', eqBars: '背景等化器', borderFrame: '粗框',
      letterbox: '電影黑邊', noiseField: '雜訊擾動'
    },
    cam: {
      push: '緩慢推近', orbitDrift: '環繞', barrelRoll: '桶滾', pendulumSway: '鐘擺', focusIn: '對焦',
      rackFocus: '失焦', earthquake: '地震', floatNoise: '漂浮', vertigo: '暈眩變焦', tiltDown: '鏡頭下搖',
      spiralIn: '漩渦變焦', snapPan: '快速橫搖', jelly: '果凍晃動', pullOut: '拉遠', panL: '向左橫搖',
      panR: '向右橫搖', tiltUp: '鏡頭上搖', dutch: '斜角鏡頭', handheld: '手持', beatPunch: '隨拍放大',
      whipIn: '急甩推入', crashZoom: '急速變焦', bounce: '彈跳', roll: '滾轉', driftDiag: '斜向漂移',
      shakeHard: '劇烈搖晃', dollyIn: '推軌', stepZoom: '分段變焦'
    },
    fx: {
      chroma: '色彩錯位跳動', shake: '搖晃', slice: '切片故障', block: '區塊故障', invert: '反轉',
      flash: '閃光', zoom: '縮放模糊', mosaic: '馬賽克', radialChroma: '放射色差', bloomFlash: '光暈',
      bulge: '魚眼', pixelSort: '像素排序', interlace: '交錯掃描', macroBlock: '區塊雜訊', halftone: '網點',
      duotone: '雙色調', ditherBit: '1 位元遞色', rotateSnap: '角度急轉', echoFrames: '殘影回聲', kaleido: '萬花筒',
      bandInvert: '帶狀反轉', lightRays: '光芒', anamorphic: '橫向光斑', heartbeat: '心跳', tvStatic: '雪花雜訊',
      dustScratches: '底片刮痕', filmAdvance: '底片捲動', perspectiveTilt: '透視搖晃', ripple: '漣漪', focusLines: '集中線',
      speedLines: '速度線', starGlint: '星芒閃光', colorBars: '彩條', zoomStutter: '連續縮放', negativeRing: '反轉圓環',
      edgeDetect: '邊緣偵測', shatter: '玻璃碎裂', defocus: '失焦', snapshot: '快門', squash: '伸縮',
      scanBar: '掃描', loopScroll: '橫向循環', panelWipe: '面板擦除', irisTrans: '光圈', doors: '門',
      blindsTrans: '百葉窗', rgbSplit: 'RGB 分離', smear: '橫向拖影', vhsRoll: 'VHS 滾動', trackingNoise: '磁軌雜訊',
      mirrorFlash: '鏡像', strobe: '頻閃', posterize: '色調分離', hueShift: '色相偏移', tileShift: '磁磚錯位',
      filmBurn: '底片燒灼', whipBlur: '急甩模糊', blackFrame: '黑畫格', whiteFrame: '白畫格', gridRepeat: '分割畫面',
      waveWarp: '波浪扭曲', pixelDrift: '像素偏移', zoomPunch: '縮放重擊', lightSweep: '光束掃過', crtOff: '映像管關機',
      splitSlide: '上下滑移'
    },
    trans: {
      wipe: '邊緣擦除', diagonalWipe: '斜帶擦除', clockWipe: '時鐘擦除', irisOpen: '光圈開啟', pushSlide: '推移',
      cover: '覆蓋', uncover: '揭開', zoomThrough: '穿越縮放', doorsOpen: '對開門', blinds: '百葉窗轉場',
      checker: '棋盤格轉場', blockDissolve: '方塊崩解', whipPan: '急甩橫搖', spinOut: '旋轉轉出', inkBlob: '墨漬',
      shatterTiles: '磁磚崩落', sliceShift: '長條錯位', cubeTurn: '立方體', flashCross: '閃光轉場', pixelate: '馬賽克轉場'
    }
  };
  for (const group of J.GROUP_KEYS) {
    const table = J.registry(group), names = titles[group] || {};
    for (const key of Object.keys(table)) if (names[key]) table[key].name = names[key];   // includes the special title / interlude layouts
  }
  const styles = {
    noir: ['暗黑色差', '黑底、白字、青色／琥珀色的色彩錯位'],
    crimson: ['深紅訊號', '深紅底、黑白雙層排版、資料毀損'],
    caution: ['警示', '黃色底、紅藍強調色、儀表介面'],
    magenta: ['普普洋紅', '螢光粉紅×白、粗圓體、標示引線'],
    paper: ['紙與墨', '紙張質感、靛藍與洋紅、明體殘影'],
    hud: ['暗色 HUD', '炭灰底、細線框、橘色點綴、日蝕'],
    mint: ['薄荷終端機', '黑×青綠×萊姆綠、標籤貼紙、狹縫掃描'],
    specimen: ['字型樣本', '墨色底、明體、辭典註解與引線'],
    transit: ['交通指標', '橄欖綠×黃色、箭頭與標誌、網點'],
    blueprint: ['藍圖', '鮮藍×白×黑、圖形拼貼、斜帶'],
    rouge: ['胭脂漸層', '淺灰底、紅色漸層、膠囊'],
    mono: ['單色 RGB', '灰色空間、白色明體、強烈 RGB 分離、座標圓'],
    sakura: ['櫻花', '淡櫻色、深梅紫、夜櫻、圓體與明體'],
    ocean: ['深海', '深藍的深海、青色螢光、泡泡與細黑體'],
    sunset: ['夕陽漸層', '橘到紫羅蘭的漸層、粗明體、逆光'],
    forest: ['森林手帖', '苔綠與米白、樹皮棕、鉛筆手寫字'],
    vapor: ['蒸氣波', '淡紫與粉彩粉紅／水藍、明體、VHS 暈染'],
    newsprint: ['報紙', '灰色新聞紙、墨黑與紅、標題明體、CMY 套印錯位與網點'],
    synth80: ['合成器 80s', '黑底霓虹洋紅／青色、立體字、掃描線'],
    kraft: ['牛皮紙', '牛皮紙與米白、朱紅與靛藍印章、紙膠帶'],
    candy: ['糖果', '薄荷／草莓／檸檬／葡萄的粉彩色、圓潤跳動的文字'],
    acid: ['酸性', '黑×酸性綠×洋紅、粗糙字型與故障畫面'],
    sumi: ['墨與朱', '和紙米白、毛筆墨字、朱紅落款'],
    gold: ['金夜', '漆黑與金箔、象牙色明體、閃爍光芒']
  };
  for (const [key, [name, desc]] of Object.entries(styles)) {
    if (J.STYLES[key]) { J.STYLES[key].name = name; J.STYLES[key].desc = desc; }
  }
  for (const [key, name] of Object.entries({glitch: '故障風', calm: '沉靜', pop: '普普', graphic: '圖形感', editorial: '編輯排版', emotional: '感性', chaos: '全都來'})) if (J.MOODS[key]) J.MOODS[key].name = name;
  J.SAMPLE_LYRICS = '晚風把影子/拉成一條線\n口袋裡還藏著沒寄出的信\n喂，現在追上去還來得及嗎\n*微光*也要燒到最後!';
})();

/* part sets (horror / typo / kinetic): names, styles and the horror mood */
(() => {
  'use strict';
  const P = {"layout": {"hrFlashlight": "手電筒", "hrDoorGap": "門縫", "hrWallScrawl": "牆上塗寫", "hrCctv": "監視螢幕", "hrOuija": "通靈板", "hrMissing": "尋人啟事", "hrWrongOne": "唯一不對的字", "hrRisingDark": "從黑暗爬出", "hrRedacted": "塗黑文件", "hrStaticTv": "雪花電視", "hrSpiritPhoto": "靈異照片", "hrWrongShadow": "不對勁的影子", "tyKeySplit": "大字夾排", "tyCropGiant": "出框大字", "tyCross": "十字排", "tyBandHide": "帶狀遮字", "tyRuby": "標音注記", "tyBaseline": "格線排版", "tyScaleSteps": "字級遞增", "tyJustify": "等寬堆疊", "tyIndexTable": "字表", "tySplitType": "斷字錯位", "tyErode": "漸削重複", "tyVRuler": "直式刻度", "tyFullTrack": "滿版字距", "tyStatCount": "字數顯示", "tyMargin": "留白", "tyRotBlock": "旋轉字塊", "tySquare": "方塊排", "tyLineFocus": "行中強調", "knSlamStack": "堆疊重擊", "knQuarterTurn": "直角轉向", "knSwapCenter": "逐字替換", "knZoomDive": "鑽入字中", "knFlowSnap": "流動後對齊", "knSeesaw": "蹺蹺板", "knTypeSlam": "打字→重擊", "knRhythmCuts": "逐字分鏡", "knPathRide": "環形軌道", "knGearWords": "齒輪", "knCollide": "正面衝撞", "knTumble": "翻滾方塊", "knReflow": "直排轉橫排", "knPadGrid": "打擊墊"}, "enter": {"hrBlinkCreep": "眨眼之間", "hrJumpScare": "突然跳出", "hrUneasy": "不安的出現", "hrVhold": "垂直同步", "hrMirrorSnap": "鏡像字", "hrManifest": "緩緩浮現", "hrClawReveal": "爪痕浮現", "tyKeyFirst": "主字先行", "tyLineWipe": "逐行擦入", "tyZoomOne": "逐字放大", "tyUnderLift": "從底線升起", "tyDotGrow": "點化為字", "tyBracketOpen": "括號展開", "tyRetype": "打錯重打", "tyRubyDrop": "從注音落下", "knWordSlam": "逐詞重擊", "knTypeToSlam": "打字→放大", "knReplaceIn": "替換登場", "knHingeDrop": "鉸鏈落下", "knLoopIn": "繞圈進場", "knPushIn": "推入", "knInertia": "急煞車", "knWordSpin": "逐詞旋轉", "knDiveIn": "從鏡頭飛入", "knStretchOut": "伸展彈出"}, "exit": {"hrPulledDown": "被拖下去", "hrLookBack": "留下一字", "hrTurnAway": "轉身背對", "hrShiver": "顫抖消失", "hrSwallow": "被黑暗吞沒", "hrFlickerDie": "閃爍熄滅", "hrDrain": "滴落", "tyStrike": "劃線刪除", "tyToDot": "縮回圓點", "tyLineFeed": "換行送出", "tyBracketClose": "括號合上", "tyToIndex": "化為編號", "tyKeyLast": "留下一字", "tyUnderSink": "沉入底線", "tyFoldVert": "折成直排", "knWordKick": "逐詞踢飛", "knPushOut": "推出退場", "knDiveGlyph": "衝入一字", "knLaunch": "急起步", "knWordBlink": "逐詞熄滅", "knCloseGap": "收攏消失", "knJumpCutOut": "跳切", "knStackAway": "疊起落下"}, "hold": {"hrTwitch": "抽搐", "hrStare": "凝視的字", "hrLagOne": "慢一拍的字", "hrFlickerLight": "將熄的燈", "tyKeyPulse": "主字脈動", "tyReadCursor": "閱讀游標", "tyOutlineBlink": "空心閃爍", "tyTrackStep": "字距跳段", "knWordPulse": "逐詞節拍", "knCounterRock": "反向搖擺", "knWordRide": "詞語衝浪", "knTickShift": "滴答位移", "knBeatLean": "隨拍傾斜", "knGapBreath": "詞間呼吸"}, "decor": {"hrScratches": "抓痕", "hrSigil": "魔法陣", "hrWatchEye": "注視之眼", "hrStaticPatch": "雜訊碎片", "hrDustBeam": "光束與塵埃", "hrDrips": "垂落的墨", "hrCracks": "裂痕", "tyColophon": "版權頁", "tyRunningHead": "書眉頁碼", "tyGlyphBody": "字身分割線", "tyTextRule": "文字線條", "tyTypeScale": "字級樣本", "tyBigPunct": "巨大引號", "knSpeedTrail": "跟隨速度線", "knWordTicks": "詞數計數器"}, "treat": {"hrInkBleed": "暈染滴落", "hrEroded": "風化", "hrRedact": "塗黑", "hrDoubleExp": "雙重曝光", "tyHollowKey": "單字鏤空", "tyHeadRules": "天地線", "tyHeadBig": "首字放大", "tyIndexSup": "字序號", "knWordScale": "大小詞", "knWordPlate": "逐詞反白"}, "bg": {"hrFailingLamp": "將熄的燈", "hrCorridor": "昏暗走廊", "hrMold": "蔓延的污漬", "hrDeadTrees": "枯樹林"}, "cam": {"hrNervous": "驚恐手持", "hrDutchSnap": "突然傾斜", "knReadPan": "隨讀平移", "knTiltKick": "逐詞傾斜", "knCardFlip": "翻牌", "knShearKick": "斜切彈動", "knJumpCut": "跳切", "knRushIn": "從遠處衝來"}, "fx": {"hrSubliminal": "潛意識閃現", "hrSignalLoss": "訊號中斷", "hrPassingShadow": "掠過的影子"}, "trans": {"hrStaticCut": "雜訊轉場", "hrBlink": "眨眼", "tyRuleWipe": "格線擦換", "tyGridCells": "稿紙格填入", "knCornerSwing": "轉角迴旋", "knStutterCut": "節奏跳切", "knStripSlam": "條幅落下"}};
  for (const [g, m] of Object.entries(P)) { const t = J.registry(g) || {}; for (const [k, n] of Object.entries(m)) if (t[k]) t[k].name = n; }
  const S = {"hrRuin": ["廢墟", "褪色灰綠、鏽紅與迴響的明朝體"], "hrNightRec": ["深夜錄影", "漆黑畫面、監視影像的白與紅、雜訊"], "hrCurse": ["詛咒之信", "泛黃信紙、褪色墨跡與暗紅筆跡"]};
  for (const [k, [n, d]] of Object.entries(S)) if (J.STYLES[k]) { J.STYLES[k].name = n; J.STYLES[k].desc = d; }
  if (J.MOODS.horror) J.MOODS.horror.name = "恐怖";
})();
